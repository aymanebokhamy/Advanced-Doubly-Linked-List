#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct node_{
  char id[20];
  long int arriv;
  double priority;
  struct node_* next;
  struct node_* prev;
}node;


void traverse(node *h);
void sort(node *h);
void search(node *h);
node* serving(node *h);
node* EditPriority(node *h);

int main(void){
  int n,i=0, ans;
  struct node_ *head,*temp, *req;
  char ID[10];
  
  FILE* inp;

  inp=fopen("data.txt","r");
  fscanf(inp,"%d",&n);

  head =(struct node_*)malloc(sizeof(node));
  temp=head;

  fscanf(inp,"%s", head->id);
  fscanf(inp,"%ld", &head->arriv);
  fscanf(inp,"%lf", &head->priority);
  
  

  do{
  req=(struct node_*)malloc(sizeof(node));
  temp->next=req;
  req->prev=temp;
  temp=temp->next;
  fscanf(inp,"%s",req->id);
  fscanf(inp,"%ld",&req->arriv);
  fscanf(inp,"%lf",&req->priority);
  i++;
  }while (i<n-1);
  sort(head);
  traverse(head);

  search(head);

    head = serving(head);
  
    head = EditPriority(head);
  
return 0;
}

node* EditPriority(node *h){
    char ID[10];
    node *walker;
    int flag = 0, ans;

  printf("\nPress 1 if you want to edit the priority of an ID. Press 0 if you don't: ");
  scanf("%d", &ans);
  if(ans == 1){

    do{
        printf("Please enter the ID you want to edit: ");
        scanf("%s", ID);

        for(walker = h; walker->next != NULL; walker = walker->next){
             if(strcmp(walker->id, ID) == 0){
                printf("The name is: %s\nThe arrival time is: %ld\nThe priority value is: %.2lf\n", walker->id, walker->arriv, walker->priority);
                flag = 1;
                break;
              }
        else continue;
        }
        if(walker->next == NULL && strcmp(walker->id, ID) == 0){
            printf("The name is: %s\nThe arrival time is: %ld\nThe priority value is: %.2lf",walker->id, walker->arriv, walker->priority);
            flag = 1;
          }
        else if(flag == 0)
            printf("This ID does not figure in the list");
        } while (flag != 1);

    printf("\nPlease enter the new priority value: ");
    scanf("%lf", &walker->priority);

    sort(h);
  }
  else return 0;

  printf("\nThe updated list is the following:\n ");
  traverse(h);
  
return h;
}

void search(node *h){
  node *walker;
  int flag = 0;
  char ID[10];

  printf("Please enter an ID to search: ");
  scanf("%s", ID);

  for(walker = h; walker->next != NULL; walker = walker->next){
      if(strcmp(walker->id, ID) == 0){
        printf("The name is: %s\nThe arrival time is: %ld\nThe priority value is: %.2lf", walker->id, walker->arriv, walker->priority);
        flag = 1;
        break;
      }
      else continue;
  }
  if(walker->next == NULL && strcmp(walker->id, ID) == 0){
    printf("The name is: %s\nThe arrival time is: %ld\nThe priority value is: %.2lf", walker->id, walker->arriv, walker->priority);
    flag = 1;
  }
  else if(flag == 0)
    printf("This ID does not figure in the list");

}

node* serving(node *h){
   node *temp;
   int ans;
   
   printf("\n\nPress 1 if you want to display the current request that has been served. Press 0 if you don't: ");
  scanf("%d", &ans);
  if(ans == 1){
      temp = h;

      printf("\n\nThe following request has been served:\nName: %s\nArrival time: %ld\nPriority value: %.2lf\n\n", temp->id, temp->arriv, temp->priority);

      h = h->next;
      free(temp); 
  }
  else return 0;

  printf("The updated list is the following:\n");
  traverse(h);


return h;
}


void traverse(node *h){
  node* rear;
  rear=h;
  while(rear!=NULL){
    printf("%s--",rear->id);
    printf("%ld--",rear->arriv);
    printf("%.2lf\n",rear->priority);
    rear=rear->next;
  }
}
void sort(node *h) {  
    struct node_ *current = NULL, *index = NULL;  
    char temp1[20];  
    double temp2;
    long int temp3;
    
    if(h == NULL) {  
        return;  
    }  
    else {  
        
        for(current = h; current->next != NULL; current = current->next) {  
              
            for(index = current->next; index != NULL; index = index->next) {  
                
                if(current->priority < index->priority) {  
                    strcpy(temp1,current->id);
                    strcpy(current->id,index->id);
                    strcpy(index->id,temp1);

                    temp2 = current->priority;  
                    current->priority = index->priority;  
                    index->priority = temp2;  

                    temp3 = current->arriv;  
                    current->arriv = index->arriv;  
                    index->arriv = temp3; 
                }  
            }  
        }  
    }  
}  

