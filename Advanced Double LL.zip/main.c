#include <stdio.h>
#include <stdlib.h>
#include <string.h>




typedef struct node_{
  char id[20];
  long int arriv;
  double priority;
  struct node_* next;
  struct node_* prev;
}node;
void search(node *h);
node* del(node* h);
node* EditPriority(node *h);
void save(node *h);
node* serving(node *h);
node* insert(node *headd);
void traverse(node *h);
void sort(node *h);
int menu(void);
void search(node *h);


int main(void){
  int n,i=0,ch;
  struct node_ *head,*temp, *req;
  FILE* inp;

  inp=fopen("data.txt","r");
  fscanf(inp,"%d",&n);

  head =(struct node_*)malloc(sizeof(node));
  temp=head;

  fscanf(inp,"%s", head->id);
  fscanf(inp,"%ld", &head->arriv);
  fscanf(inp,"%lf", &head->priority);
  
  do{
  req=(struct node_*)malloc(sizeof(node));
  temp->next=req;
  req->prev=temp;
  temp=temp->next;
  fscanf(inp,"%s",req->id);
  fscanf(inp,"%ld",&req->arriv);
  fscanf(inp,"%lf",&req->priority);
  i++;
  }while (i<n-1);
  
  sort(head);
  
  traverse(head);
  
  ch=menu();
do{
  
  switch(ch){
    case 1:
      head=insert(head);
      ch=menu();
      break;
    case 2:
      search(head);
      ch=menu();
      break;
    case 3:
      head=del(head);
      ch =menu();
      break;
    case 4:
    head=serving(head);
      ch=menu();
      break;
    case 5:
      traverse(head);
      ch=menu();
      break;
    case 6:
      head=EditPriority(head);
      ch=menu();
      break;
    case 7:
      save(head);
      ch=menu();
      break;
  }
}while(ch!=8);
  printf("You exited the program");
  
  fclose(inp);

return 0;
}


void traverse(node *h){
  node* rear;
  printf("\n");
  rear=h;
  while(rear!=NULL){
    printf("%s--",rear->id);
    printf("%ld--",rear->arriv);
    printf("%.2lf\n",rear->priority);
    rear=rear->next;
  }
}
void sort(node *h) {  
    struct node_ *current = NULL, *index = NULL;  
    char temp1[20];  
    double temp2;
    long int temp3;
    
    if(h == NULL) {  
        return;  
    }  
    else {  
        
        for(current = h; current->next != NULL; current = current->next) {  
              
            for(index = current->next; index != NULL; index = index->next) {  
                
                if(current->priority < index->priority) {  
                    strcpy(temp1,current->id);
                    strcpy(current->id,index->id);
                    strcpy(index->id,temp1);

                    temp2 = current->priority;  
                    current->priority = index->priority;  
                    index->priority = temp2;  

                    temp3 = current->arriv;  
                    current->arriv = index->arriv;  
                    index->arriv = temp3;  
                }  
            }  
        }  
    }  
}  

node* insert(node *headd){
  node *newelt, *walker;
  newelt =(struct node_*)malloc(sizeof(node));
  printf("\n");
  printf("please enter the ID\n");
  scanf("%s",newelt->id);
  printf("Please enter the arrival time\n");
  scanf("%ld",&newelt->arriv);
  printf("Please enter the priority value\n");
  scanf("%lf",&newelt->priority);
  walker=headd;
  while(walker->next!=NULL){
    walker=walker->next;
  }
  walker->next=newelt;
  newelt->next=NULL;
  newelt->prev=walker;
  sort(headd);
  return headd;
}
node* del(node* h){
  char id_del[20];
  node *walker,*previous, *end,*previousend,*temp;
  printf("\n");
  printf("Please enter the ID of the request you wish to delete\n");
  scanf("%s",id_del);
  walker=h->next;
  end=h;
  while(end->next!=NULL){
    end=end->next;
  }

  previousend=end->prev;
  previous=walker->prev;


  if(strcmp(end->id,id_del)==0){
    previousend->next=NULL;
    free(end);
    return h;
  }
  else if(strcmp(h->id,id_del)==0){
    temp=h;
    h=h->next;
    h->prev=NULL;
    free(temp);
    return h;
  }
  else{
    do{
      if(strcmp(walker->id,id_del)==0){
        previous->next=walker->next; 
        walker->next->prev=previous; 
        free(walker);
        return h;
      }
      walker=walker->next;
      previous=previous->next;
    }while(walker->next!=NULL);
  }


  printf("The request you want to delete doesn't figure on the list\n");

  return h;
}
int menu(void){
  int choice;
  printf("Please enter 1 to create a new request.\nPlease enter 2 to search for a request.\nPlease enter 3 to delete a request.\nPlease enter 4 to serve a request.\nPlease enter 5 to display current requests.\nPlease enter 6 to increase or decrease the priority of a request.\nPlease enter 7 to save.\nPlease enter 8 to exit\n");
  scanf("%d",&choice);
  return choice;
}

void search(node *h){
  node *walker;
  int flag = 0;
  char ID[10];
  printf("\n");
  printf("Please enter an ID to search: ");
  scanf("%s", ID);

  for(walker = h; walker->next != NULL; walker = walker->next){
      if(strcmp(walker->id, ID) == 0){
        printf("The name is: %s\nThe arrival time is: %ld\nThe priority value is: %.2lf\n", walker->id, walker->arriv, walker->priority);
        flag = 1;
        break;
      }
      else continue;
  }
  if(walker->next == NULL && strcmp(walker->id, ID) == 0){
    printf("The name is: %s\nThe arrival time is: %ld\nThe priority value is: %.2lf", walker->id, walker->arriv, walker->priority);
    flag = 1;
  }
  else if(flag == 0)
    printf("This ID does not figure in the list\n");

}
void save(node *h){
  FILE* outp;
  node *walker;
  outp=fopen("data.txt","w");
  walker=h;
  sort(h);  

  while(walker!=NULL){
    fprintf(outp,"%s ",walker->id);
    fprintf(outp,"%ld ",walker->arriv);
    fprintf(outp,"%lf\n",walker->priority);
    walker=walker->next;
  }

    fclose(outp);

  
}

node* serving(node *h){
   node *temp;
   int ans;
   printf("\n");
   printf("\n\nPress 1 if you want to display the current request that has been served. Press 0 if you don't: ");
  scanf("%d", &ans);
  if(ans == 1){
      temp = h;

      printf("\n\nThe following request has been served:\nName: %s\nArrival time: %ld\nPriority value: %.2lf\n\n", temp->id, temp->arriv, temp->priority);

      h = h->next;
      free(temp); 
  }
  else return 0;

  printf("The updated list is the following:\n");
  traverse(h);


return h;
}
node* EditPriority(node *h){
    char ID[10];
    node *walker;
    int flag = 0, ans;
  printf("\n");
  printf("\nPress 1 if you want to edit the priority of an ID. Press 0 if you don't: ");
  scanf("%d", &ans);
  if(ans == 1){

    do{
        printf("Please enter the ID you want to edit: ");
        scanf("%s", ID);

        for(walker = h; walker->next != NULL; walker = walker->next){
             if(strcmp(walker->id, ID) == 0){
                printf("The name is: %s\nThe arrival time is: %ld\nThe priority value is: %.2lf\n", walker->id, walker->arriv, walker->priority);
                flag = 1;
                break;
              }
        else continue;
        }
        if(walker->next == NULL && strcmp(walker->id, ID) == 0){
            printf("The name is: %s\nThe arrival time is: %ld\nThe priority value is: %.2lf",walker->id, walker->arriv, walker->priority);
            flag = 1;
          }
        else if(flag == 0)
            printf("This ID does not figure in the list");
        } while (flag != 1);

    printf("\nPlease enter the new priority value: ");
    scanf("%lf", &walker->priority);

    sort(h);
  }
  else return 0;

  printf("\nThe updated list is the following:\n ");
  traverse(h);
  
return h;
}